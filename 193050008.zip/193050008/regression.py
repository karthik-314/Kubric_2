import requests
import pandas as pd
from scipy import stats as st
import numpy
import sys
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split 


TRAIN_DATA_URL = "https://storage.googleapis.com/kubric-hiring/linreg_train.csv"
TEST_DATA_URL = "https://storage.googleapis.com/kubric-hiring/linreg_test.csv"


def predict_price(area) -> float:
    """
    This method must accept as input an array `area` (represents a list of areas sizes in sq feet) and must return the respective predicted prices (price per sq foot) using the linear regression model that you build.

    You can run this program from the command line using `python3 regression.py`.
    """
    # response = requests.get(TRAIN_DATA_URL)
    df = pd.read_csv(TRAIN_DATA_URL, index_col=0, header=None).transpose()
    # df = df.iloc[0:]
    # df.div(df.sum(axis=1), axis=0)

    # a = df[0][0:][1:3]
    # print(.shape)
    # print(df['price'])
    first_col = list(df['area'])
    second_col = list(df['price'])
    X = numpy.array(first_col)
    Y = numpy.array(second_col)
    tan, intercept, x, y, my_err = st.linregress(X, Y)
    area = numpy.array(area)
    return area * tan + intercept
    # X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.25)
    # regr = LinearRegression()
    # regr.fit(X_train, Y_train)
    # print(regr.score(X_test, Y_test))

    # return 0.2
    # print(response)
    # YOUR IMPLEMENTATION HERE
    ...


if __name__ == "__main__":
    # DO NOT CHANGE THE FOLLOWING CODE
    from data import validation_data
    areas = numpy.array(list(validation_data.keys()))
    prices = numpy.array(list(validation_data.values()))
    predicted_prices = predict_price(areas)
    rmse = numpy.sqrt(numpy.mean((predicted_prices - prices) ** 2))
    try:
        assert rmse < 170
    except AssertionError:
        print(f"Root mean squared error is too high - {rmse}. Expected it to be under 170")
        sys.exit(1)
    print(f"Success. RMSE = {rmse}")
